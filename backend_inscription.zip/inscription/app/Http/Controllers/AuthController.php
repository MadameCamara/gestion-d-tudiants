<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use App\Models\User;

class AuthController extends Controller
{
    public function createUser(Request $request)
    {
        try
        {
            $validator = Validator::make($request->all(),
            [
                "name"=> "required",
                "email"=> "required|email|unique:users,email",
                "password"=> "required",
            ]);

            if($validator->fails())
            {
                return response()->json(
                [
                    "status"=> false,
                    "message"=> "Erreur de validation",
                    "error"=> $validator->errors()->first(),
                ], 401);
            }

            $user = User::create(
            [
                "name"=> $request->name,
                "email"=> $request->email,
                "password"=> Hash::make($request->password),
            ]);

            return response()->json(
            [
                "status"=> true,
                "message"=> "Utilisateur cree avec succes",
                "token"=> $user->createToken("API TOKEN")->plainTextToken,
            ], 200);
        }
        catch (\Throwable $e)
        {
            return response()->json([
                "status"=> false,
                "message"=> $e->getMessage()
            ], 500);
        }
    }

    public function login(Request $request)
    {
        try
        {
            $validator = Validator::make($request->all(),
            [
                "email"=> "required",
                "password"=> "required",
            ]);

            if($validator->fails())
            {
                return response()->json(
                [
                    "status"=> false,
                    "message"=> "Erreur de validation",
                    "error"=> $validator->errors()->first(),
                ], 401);
            }

            if(!Auth::attempt($request->only(["email", "password"])))
            {
                return response()->json(
                [
                    "status"=> false,
                    "message"=> "Email ou le mot de password ne correspond pas!"
                ], 401);
            }

            $user = User::where("email", $request->email)->first();

            return response()->json(
            [
                "status"=> true,
                "message"=> "Connection reussie",
                "token"=> $user->createToken("API TOKEN")->plainTextToken,

            ], 200);
        }
        catch (\Throwable $e)
        {
            return response()->json([
                "status"=> false,
                "message"=> $e->getMessage()
            ], 500);
        }
    }
}
