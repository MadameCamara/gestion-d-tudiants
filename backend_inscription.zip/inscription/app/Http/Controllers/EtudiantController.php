<?php

namespace App\Http\Controllers;

use App\Models\Etudiant;
use Illuminate\Http\Request;

class EtudiantController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $etudiant = Etudiant::all();
        return response()->json($etudiant);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(Request $request, Etudiant $etudiant)
    {
        $nom = $request->nom;
        $prenom = $request->prenom;
        $code = $request->code;
        $ine = $request->ine;
        $email_ugb = $request->email_ugb;
        $email_perso = $request->email_perso;
        $adresse = $request->adresse;
        $date_naissance = $request->date_naissance;
        $lieu_naissance = $request->lieu_naissance;
        $tel = $request->tel;

        $etudiant->nom = $nom;
        $etudiant->prenom = $prenom;
        $etudiant->code = $code;
        $etudiant->ine = $ine;
        $etudiant->email_ugb = $email_ugb;
        $etudiant->email_perso = $email_perso;
        $etudiant->adresse = $adresse;
        $etudiant->date_naissance = $date_naissance;
        $etudiant->lieu_naissance = $lieu_naissance;
        $etudiant->tel = $tel;
        $etudiant->save();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $etudiant = Etudiant::find($id);
        return response()->json($etudiant);
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Request $request)
    {
        $id = $request->id;
        $nom = $request->nom;
        $prenom = $request->prenom;
        $code = $request->code;
        $ine = $request->ine;
        $email_ugb = $request->email_ugb;
        $email_perso = $request->email_perso;
        $adresse = $request->adresse;
        $date_naissance = $request->date_naissance;
        $lieu_naissance = $request->lieu_naissance;
        $tel = $request->tel;

        $etudiant = Etudiant::find($id);
        $etudiant->nom = $nom;
        $etudiant->prenom = $prenom;
        $etudiant->code = $code;
        $etudiant->ine = $ine;
        $etudiant->email_ugb = $email_ugb;
        $etudiant->email_perso = $email_perso;
        $etudiant->adresse = $adresse;
        $etudiant->date_naissance = $date_naissance;
        $etudiant->lieu_naissance = $lieu_naissance;
        $etudiant->tel = $tel;
        $etudiant->save();
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Etudiant $etudiant)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        Etudiant::destroy($id);
    }
}
