<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class InscriptionSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table("inscriptions")->delete();
        DB::table("inscriptions")->insert(
        [
            [
                "etudiant_id"=> 1,
                "niveau_id"=> 1,
                "formation_id"=> 1,
                "annee_id"=> 1,
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "etudiant_id"=> 2,
                "niveau_id"=> 2,
                "formation_id"=> 2,
                "annee_id"=> 1,
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "etudiant_id"=> 3,
                "niveau_id"=> 3,
                "formation_id"=> 3,
                "annee_id"=> 1,
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ]
        ]);
    }
}
