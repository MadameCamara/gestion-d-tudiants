<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class EtudiantSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table("etudiants")->delete();
        DB::table("etudiants")->insert(
        [
            [
                "nom"=> "DIALLO",
                "prenom"=> "Amadou",
                "code"=> "P32",
                "ine"=> "N23",
                "email_ugb"=> "diallo@gmail.com",
                "email_perso"=> "diallo@ugb.edu.com",
                "adresse"=> "Dakar, Medina, Rue 9",
                "date_naissance"=> "01/01/2000",
                "lieu_naissance"=> "Bambey",
                "tel"=> "77 586 10 45",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "nom"=> "SECK",
                "prenom"=> "Fatou",
                "code"=> "P30",
                "ine"=> "N21",
                "email_ugb"=> "seck@gmail.com",
                "email_perso"=> "seck@ugb.edu.com",
                "adresse"=> "Dakar, Pikine, Icotaf",
                "date_naissance"=> "12/11/2004",
                "lieu_naissance"=> "Ziguinchor",
                "tel"=> "78 486 18 00",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "nom"=> "LAHM",
                "prenom"=> "Aly",
                "code"=> "P33",
                "ine"=> "N52",
                "email_ugb"=> "Lahm@gmail.com",
                "email_perso"=> "lahm@ugb.edu.com",
                "adresse"=> "Thies, Medina, Rue 9",
                "date_naissance"=> "10/10/2002",
                "lieu_naissance"=> "Tambacounda",
                "tel"=> "70 856 77 19",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],

            [
                "nom"=> "ba",
                "prenom"=> "Aly",
                "code"=> "P29",
                "ine"=> "N52",
                "email_ugb"=> "ba@gmail.com",
                "email_perso"=> "ba@ugb.edu.com",
                "adresse"=> "Thies, Medina, Rue 9",
                "date_naissance"=> "10/10/2002",
                "lieu_naissance"=> "Tambacounda",
                "tel"=> "70 856 77 19",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ]
        ]);
    }
}
