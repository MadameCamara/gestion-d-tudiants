<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class FormationSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table("formations")->delete();
        DB::table("formations")->insert(
        [
            [
                "libelle"=> "MIAGE",
                "ufr"=> "SEG",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "libelle"=> "MASS",
                "ufr"=> "SAT",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "libelle"=> "Informatique",
                "ufr"=> "SAT",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "libelle"=> "physique",
                "ufr"=> "LSH",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ]
        ]);
    }
}
