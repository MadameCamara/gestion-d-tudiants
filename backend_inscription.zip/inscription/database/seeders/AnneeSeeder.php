<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class AnneeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        DB::table("annees")->delete();
        DB::table("annees")->insert(
        [
            [
                "libelle"=> "2022/2023",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "libelle"=> "2021/2022",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "libelle"=> "2020/2021",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ],
            [
                "libelle"=> "2022/2023",
                "created_at"=> date("Y-m-d H:i:s"),
                "updated_at"=> date("Y-m-d H:i:s")
            ]
        ]);
    }
}
