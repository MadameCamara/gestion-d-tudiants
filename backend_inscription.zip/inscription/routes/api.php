<?php

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\EtudiantController;
use App\Http\Controllers\InscriptionController;
use App\Http\Controllers\FormationController;
use App\Http\Controllers\NiveauController;
use App\Http\Controllers\AnneeController;
use App\Http\Controllers\AuthController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "api" middleware group. Make something great!
|
*/

Route::middleware('auth:sanctum')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/login', [AuthController::class, 'login']);
Route::post('/createUser', [AuthController::class, 'createUser']);

    

Route::middleware('auth:sanctum')->group(function ()
{
  //  Route::get('/etudiants', [EtudiantController::class, 'index']);

  Route::get('/etudiants', [EtudiantController::class, 'index']);
  Route::post('/etudiants/create', [EtudiantController::class, 'create']);
  Route::get('/etudiants/show/{id}', [EtudiantController::class, 'show']);
  Route::delete('/etudiants/destroy/{id}', [EtudiantController::class, 'destroy']);
     
  Route::put('/etudiants/edit', [EtudiantController::class, 'edit']);
  Route::get('/niveaux', [NiveauController::class, 'index']);
  Route::get('/formations', [FormationController::class, 'index']);
  Route::get('/annees', [AnneeController::class, 'index']);
  //Route::get('/inscriptions', [InscriptionController::class, 'index']);
  Route::get('/inscriptionsListe', [InscriptionController::class, 'getAllInscriptions']);
  Route::post('/inscriptions/create', [InscriptionController::class, 'create']);

    
});